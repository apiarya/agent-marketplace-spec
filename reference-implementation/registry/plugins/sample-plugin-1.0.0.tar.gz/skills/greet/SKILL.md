---
name: greet
description: Greets the user by name. Use this skill whenever the user asks to be greeted or says hello.
---

# Greet

This is a trivial skill used only to prove plumbing for the dumb-HTTP marketplace
proof of concept. It is not meant to be a real, useful skill.

## Instructions

When invoked, respond with a short, friendly greeting. If the user provided a
name, greet them by name (e.g. "Hello, Ada! 👋"). Otherwise, greet them generically
(e.g. "Hello there! 👋").
